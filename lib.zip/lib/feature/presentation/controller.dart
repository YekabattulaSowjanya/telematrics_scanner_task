import 'package:http/http.dart' as http;
import 'dart:convert';
import '../data/models/Vehicle.dart';

Future<Vehicle> fetchVehicleOptions() async {
  final url = Uri.parse("http://103.123.173.50:8090/jhsmobileapi/mobile/configure/v1/task");

  final payload = {
    "clientid": 11,
    "enterprise_code": 1007,
    "mno": "9889897789",
    "passcode": 3476,
  };

  final response = await http.post(
    url,
    headers: {"Content-Type": "application/json"},
    body: json.encode(payload),
  );

  if (response.statusCode == 200) {
    // Parse the response and return a Vehicle object
    return Vehicle.fromJson(json.decode(response.body));
  } else {
    throw Exception('Failed to load vehicle options');
  }
}
