import 'package:flutter/material.dart';
import '../../core/custom_dropdown.dart';
import '../../core/custom_textformfield.dart';
import '../data/models/Vehicle.dart';
import 'controller.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String? _selectedDropdown1;
  String? _selectedDropdown2;
  String? _selectedDropdown3;
  String? _selectedDropdown4;
  String? _selectedDropdown5;
  int _selectedValue = -1;

  late Future<Vehicle> vehicleOptions;

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _registrationNoController = TextEditingController();

  @override
  void initState() {
    super.initState();
    vehicleOptions = fetchVehicleOptions(); // Fetch data when the screen loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 8, right: 8, top: 5, bottom: 5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () {},
                    icon: const Icon(
                      Icons.arrow_back,
                      color: Colors.black,
                      size: 40,
                    ),
                  ),
                  const Text(
                    "Add vehicle",
                    style: TextStyle(color: Colors.black, fontSize: 22),
                  ),
                ],
              ),
              SizedBox(height: 5,),
              CustomTextField(
                controller: _nameController,
                label: "name",
                hint: "tag name",
                prefixIcon: Icon(Icons.email),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Please enter tag name";
                  }
                  return null;
                },
              ),
              SizedBox(height: 5,),
              CustomTextField(
                controller: _registrationNoController,
                label: "registration number",
                hint: "Enter your registration number",
                prefixIcon: Icon(Icons.email),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Please enter your registration number";
                  }
                  return null;
                },
              ),
              SizedBox(height: 5),
              // Use FutureBuilder to fetch and display dropdown options
              FutureBuilder<Vehicle>(
                future: vehicleOptions,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  } else if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  } else if (snapshot.hasData) {
                    final vehicle = snapshot.data!;
                    return Column(
                      children: [
                        // Dropdown for Vehicle Type
                        CustomDropdown(
                          hintText: 'Select Vehicle Type',
                          value: _selectedDropdown1,
                          items: vehicle.vehicleType!.map((e) => e.text!).toList(),
                          onChanged: (newValue) {
                            setState(() {
                              _selectedDropdown1 = newValue;
                            });
                          },
                        ),
                        SizedBox(height: 5),
                        // Dropdown for Vehicle Make
                        CustomDropdown(
                          hintText: 'Select Vehicle Make',
                          value: _selectedDropdown2,
                          items: vehicle.vehicleMake!.map((e) => e.text!).toList(),
                          onChanged: (newValue) {
                            setState(() {
                              _selectedDropdown2 = newValue;
                            });
                          },
                        ),
                        SizedBox(height: 5),
                        // Dropdown for Vehicle Capacity
                        CustomDropdown(
                          hintText: 'Select Vehicle Capacity',
                          value: _selectedDropdown3,
                          items: vehicle.vehicleCapacity!.map((e) => e.text!).toList(),
                          onChanged: (newValue) {
                            setState(() {
                              _selectedDropdown3 = newValue;
                            });
                          },
                        ),
                        SizedBox(height: 5),
                        // Dropdown for Manufacture Year
                        CustomDropdown(
                          hintText: 'Select Manufacture Year',
                          value: _selectedDropdown4,
                          items: vehicle.manufactureYear!.map((e) => e.text!).toList(),
                          onChanged: (newValue) {
                            setState(() {
                              _selectedDropdown4 = newValue;
                            });
                          },
                        ),
                        SizedBox(height: 5),
                        // Dropdown for Fuel Type
                        CustomDropdown(
                          hintText: 'Select Fuel Type',
                          value: _selectedDropdown5,
                          items: vehicle.fuelType!.map((e) => e.text!).toList(),
                          onChanged: (newValue) {
                            setState(() {
                              _selectedDropdown5 = newValue;
                            });
                          },
                        ),
                      ],
                    );
                  } else {
                    return Center(child: Text('No data available'));
                  }
                },
              ),
                SizedBox(height: 5,),
                Text('Select an option:'),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: ListTile(
                        title: Text('temp'),
                        leading: Radio<int>(
                          value: 1,
                          groupValue: _selectedValue,
                          activeColor: Colors.pink, // Set pink color for the selected radio button
                          onChanged: (int? value) {
                            setState(() {
                              _selectedValue = value!;
                            });
                          },
                        ),
                      ),
                    ),
                    Expanded(
                      child: ListTile(
                        title: Text('perminent'),
                        leading: Radio<int>(
                          value: 2,
                          groupValue: _selectedValue,
                          activeColor: Colors.pink, // Set pink color for the selected radio button
                          onChanged: (int? value) {
                            setState(() {
                              _selectedValue = value!;
                            });
                          },
                        ),
                      ),
                    )
                  ],
                ),
      
              ],
            ),
          ),
      ),
    );
  }
}
